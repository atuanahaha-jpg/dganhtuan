import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Navbar } from "@/components/navbar";
import { db } from "@/lib/db";

export async function generateMetadata({ params }: { params: Promise<{ username: string }> }) {
  const { username } = await params;
  const user = await db.user.findUnique({ where: { username }, select: { name: true, username: true, bio: true } });
  return { title: user ? `${user.name || user.username} (@${user.username})` : "Profile" };
}
export default async function ProfilePage({ params }: { params: Promise<{ username: string }> }) {
  const { username } = await params;
  const user = await db.user.findUnique({ where: { username }, include: { _count: { select: { posts: true, followers: true, following: true } }, posts: { where: { published: true, visibility: "PUBLIC" }, orderBy: { createdAt: "desc" }, take: 36, include: { images: { take: 1 }, _count: { select: { likes: true } } } } } });
  if (!user) notFound();
  return <><Navbar/><main className="container py-10"><section className="glass rounded-3xl p-6 sm:p-10"><div className="flex flex-col gap-5 sm:flex-row sm:items-center"><div className="grid size-24 shrink-0 place-items-center rounded-full bg-gradient-to-br from-blue-500 to-violet-500 text-3xl font-bold">{(user.name||user.username).slice(0,1).toUpperCase()}</div><div className="flex-1"><h1 className="font-display text-3xl font-bold">{user.name||user.username}</h1><p className="mt-1 text-sm text-muted">@{user.username}</p>{user.bio&&<p className="mt-3 max-w-2xl text-sm leading-6">{user.bio}</p>}</div><Link href="/settings" className="rounded-full border border-border px-4 py-2 text-sm">Edit profile</Link></div><div className="mt-7 flex gap-8 border-t border-border pt-5 text-sm"><span><strong>{user._count.posts}</strong> <span className="text-muted">Posts</span></span><span><strong>{user._count.followers}</strong> <span className="text-muted">Followers</span></span><span><strong>{user._count.following}</strong> <span className="text-muted">Following</span></span></div></section><h2 className="mb-5 mt-9 font-display text-xl font-bold">Published posts</h2><div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">{user.posts.map((post)=><Link href={`/p/${post.id}`} key={post.id} className="group overflow-hidden rounded-2xl border border-border bg-surface"><div className="relative aspect-[4/5]">{post.images[0]&&<Image src={post.images[0].url} alt={post.images[0].altText} fill unoptimized className="object-cover transition group-hover:scale-105"/>}</div><div className="p-3"><p className="truncate text-sm font-medium">{post.title}</p><p className="mt-1 text-xs text-muted">{post._count.likes} likes</p></div></Link>)}</div></main></>;
}
