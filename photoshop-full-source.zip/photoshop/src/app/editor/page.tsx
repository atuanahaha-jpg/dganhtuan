"use client";
import { useRef, useState } from "react";
import { Navbar } from "@/components/navbar";
import { SlidersHorizontal, RotateCw, Download, ImagePlus } from "lucide-react";

export default function EditorPage() {
  const input = useRef<HTMLInputElement>(null);
  const [src, setSrc] = useState("");
  const [brightness, setBrightness] = useState(100);
  const [contrast, setContrast] = useState(100);
  const [saturate, setSaturate] = useState(100);
  const [blur, setBlur] = useState(0);
  const [rotation, setRotation] = useState(0);
  const [flip, setFlip] = useState(false);
  const filter = `brightness(${brightness}%) contrast(${contrast}%) saturate(${saturate}%) blur(${blur}px)`;
  function download() {
    const image = new Image();
    image.crossOrigin = "anonymous";
    image.onload = () => {
      const canvas = document.createElement("canvas");
      const swap = Math.abs(rotation % 180) === 90;
      canvas.width = swap ? image.naturalHeight : image.naturalWidth;
      canvas.height = swap ? image.naturalWidth : image.naturalHeight;
      const context = canvas.getContext("2d");
      if (!context) return;
      context.translate(canvas.width/2, canvas.height/2);
      context.rotate(rotation*Math.PI/180);
      context.scale(flip?-1:1,1);
      context.filter = filter;
      context.drawImage(image,-image.naturalWidth/2,-image.naturalHeight/2);
      const anchor = document.createElement("a");
      anchor.download = "photoshop-edited.png";
      anchor.href = canvas.toDataURL("image/png");
      anchor.click();
    };
    image.src = src;
  }
  return <><Navbar/><main className="container max-w-6xl py-8"><div className="mb-7"><p className="text-xs font-semibold uppercase tracking-[.2em] text-primary">Creative tools</p><h1 className="mt-2 font-display text-3xl font-bold">Photo editor</h1><p className="mt-2 text-muted">Make quick adjustments right in your browser. Your original file stays untouched.</p></div><div className="grid gap-5 lg:grid-cols-[1fr_320px]"><section className="flex min-h-[420px] items-center justify-center overflow-hidden rounded-2xl border border-border bg-black/30 p-4">{src?<img src={src} alt="Editing preview" style={{filter,transform:`rotate(${rotation}deg) scaleX(${flip?-1:1})`}} className="max-h-[70vh] max-w-full object-contain"/>:<button onClick={()=>input.current?.click()} className="flex flex-col items-center gap-3 rounded-2xl border border-dashed border-border p-12 text-muted hover:border-primary hover:text-foreground"><ImagePlus size={32}/><span className="font-medium">Choose an image to edit</span><span className="text-xs">Your image is processed locally</span></button>}<input ref={input} type="file" accept="image/*" className="hidden" onChange={(e)=>{const file=e.target.files?.[0];if(file)setSrc(URL.createObjectURL(file));}}/></section><aside className="rounded-2xl border border-border bg-surface p-5"><h2 className="flex items-center gap-2 font-semibold"><SlidersHorizontal size={17}/> Adjustments</h2>{[["Brightness",brightness,setBrightness,0,200],["Contrast",contrast,setContrast,0,200],["Saturation",saturate,setSaturate,0,200],["Blur",blur,setBlur,0,10]].map(([name,value,setter,min,max])=><label key={String(name)} className="mt-6 block text-sm"><span className="flex justify-between"><span>{String(name)}</span><span className="text-muted">{String(value)}{name==="Blur"?"px":"%"}</span></span><input type="range" min={Number(min)} max={Number(max)} value={Number(value)} onChange={(e)=>(setter as (value:number)=>void)(Number(e.target.value))} className="mt-3 w-full accent-blue-500"/></label>)}<div className="mt-6 grid grid-cols-2 gap-2"><button onClick={()=>setRotation((x)=>x+90)} className="inline-flex items-center justify-center gap-2 rounded-xl border border-border p-3 text-sm"><RotateCw size={16}/> Rotate</button><button onClick={()=>setFlip(!flip)} className="rounded-xl border border-border p-3 text-sm">{flip?"Unflip":"Flip horizontal"}</button></div><button onClick={()=>{setBrightness(100);setContrast(100);setSaturate(100);setBlur(0);setRotation(0);setFlip(false);}} className="mt-3 w-full rounded-xl border border-border p-3 text-sm">Reset adjustments</button><button disabled={!src} onClick={download} className="mt-3 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-primary p-3 text-sm font-semibold text-white disabled:opacity-40"><Download size={16}/> Export PNG</button></aside></div></main></>;
}
