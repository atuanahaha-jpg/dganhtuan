import Link from "next/link";
import { ArrowRight, Sparkles, TrendingUp, Users, Camera } from "lucide-react";
import { Navbar } from "@/components/navbar";
import { Feed } from "@/components/feed";

const categories = ["All", "Nature", "Photography", "Travel", "Architecture", "Animals", "Art", "Food", "Technology", "Minimal"];

export default function HomePage() {
  return <><Navbar/><main>
    <section className="container pt-8 sm:pt-12">
      <div className="relative isolate overflow-hidden rounded-[28px] border border-border bg-hero-mesh px-6 py-10 sm:px-12 sm:py-16 lg:px-16">
        <div className="absolute inset-0 -z-10 bg-[linear-gradient(120deg,hsl(var(--surface)),transparent_75%)]"/>
        <div className="max-w-2xl">
          <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-3 py-1.5 text-xs font-medium text-blue-300"><Sparkles size={14}/> A creative community for everyone</div>
          <h1 className="font-display text-4xl font-bold leading-[1.08] tracking-tight sm:text-6xl">Discover beautiful moments.<br/><span className="bg-gradient-to-r from-blue-400 via-violet-400 to-pink-300 bg-clip-text text-transparent">Share your world.</span></h1>
          <p className="mt-5 max-w-lg text-base leading-7 text-muted sm:text-lg">A place for photographers, dreamers, and curious minds. Find inspiration, tell your story, and connect through images.</p>
          <div className="mt-8 flex flex-wrap gap-3"><Link href="/upload" className="inline-flex items-center gap-2 rounded-full bg-primary px-5 py-3 text-sm font-semibold text-white shadow-glow transition hover:brightness-110"><Camera size={17}/> Start creating <ArrowRight size={16}/></Link><Link href="/trending" className="inline-flex items-center gap-2 rounded-full border border-border bg-surface/70 px-5 py-3 text-sm font-semibold hover:bg-elevated"><TrendingUp size={17}/> Explore trending</Link></div>
          <div className="mt-9 flex flex-wrap gap-6 text-xs text-muted"><span className="inline-flex items-center gap-2"><Users size={15}/> A community for all</span><span className="inline-flex items-center gap-2"><Sparkles size={15}/> Your creativity, your space</span></div>
        </div>
        <div className="pointer-events-none absolute -right-20 -top-20 -z-10 size-96 rounded-full bg-blue-500/10 blur-3xl"/>
      </div>
    </section>
    <section className="container py-8">
      <div className="mb-6 flex items-end justify-between gap-4"><div><p className="text-xs font-semibold uppercase tracking-[.22em] text-primary">Find your inspiration</p><h2 className="mt-2 font-display text-2xl font-bold sm:text-3xl">Made by the community</h2></div><Link href="/trending" className="inline-flex items-center gap-1 text-sm text-muted hover:text-foreground">View trending <ArrowRight size={15}/></Link></div>
      <div className="mb-7 flex gap-2 overflow-x-auto pb-2">{categories.map((category, index) => <Link key={category} href={index === 0 ? "/" : `/search?q=${encodeURIComponent(category.toLowerCase())}`} className={`shrink-0 rounded-full border px-4 py-2 text-sm transition ${index === 0 ? "border-primary bg-primary text-white" : "border-border bg-surface text-muted hover:border-primary/50 hover:text-foreground"}`}>{category}</Link>)}</div>
      <Feed/>
    </section>
  </main><footer className="border-t border-border"><div className="container flex flex-col gap-4 py-8 text-sm text-muted sm:flex-row sm:items-center sm:justify-between"><Link href="/" className="font-display font-bold text-foreground">Photoshop</Link><p>More than just images. It’s a community.</p><div className="flex gap-4"><Link href="/about" className="hover:text-foreground">About</Link><Link href="/terms" className="hover:text-foreground">Terms</Link><Link href="/privacy" className="hover:text-foreground">Privacy</Link></div></div></footer></>;
}
