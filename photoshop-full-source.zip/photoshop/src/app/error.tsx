"use client";
import { useEffect } from "react";
export default function ErrorPage({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => { console.error(error); }, [error]);
  return <main className="grid min-h-screen place-items-center px-6"><div className="max-w-md text-center"><h1 className="font-display text-3xl font-bold">Something went wrong</h1><p className="mt-3 text-muted">We couldn’t load this part of Photoshop. Try again.</p><button onClick={reset} className="mt-6 rounded-full bg-primary px-5 py-3 text-sm font-semibold text-white">Try again</button></div></main>;
}
