import Link from "next/link";
import { Navbar } from "@/components/navbar";
import { Images, LockKeyhole } from "lucide-react";
import { auth } from "@/lib/auth";
import { db } from "@/lib/db";

export const metadata = { title: "Albums" };
export default async function AlbumsPage() {
  const session = await auth();
  const albums = session?.user?.id ? await db.album.findMany({ where: { userId: session.user.id }, include: { _count: { select: { items: true } } }, orderBy: { updatedAt: "desc" } }) : [];
  return <><Navbar/><main className="container py-10"><div className="flex flex-wrap items-end justify-between gap-4"><div><p className="text-xs font-semibold uppercase tracking-[.2em] text-primary">Keep it together</p><h1 className="mt-2 font-display text-3xl font-bold">Your albums</h1><p className="mt-2 text-muted">Curate collections around the things you love.</p></div><Link href="/login" className="rounded-full bg-primary px-4 py-2.5 text-sm font-semibold text-white">Create album</Link></div>{!session ? <div className="mt-8 rounded-2xl border border-border p-8 text-center"><LockKeyhole className="mx-auto text-muted"/><p className="mt-3 font-semibold">Sign in to manage your albums</p><Link href="/login" className="mt-3 inline-block text-sm text-primary">Sign in</Link></div> : albums.length ? <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{albums.map((album)=><article key={album.id} className="glass rounded-2xl p-5"><Images className="text-primary"/><h2 className="mt-4 font-semibold">{album.title}</h2><p className="mt-1 text-sm text-muted">{album._count.items} posts · {album.isPublic?"Public":"Private"}</p><p className="mt-4 text-xs text-muted">/{album.slug}</p></article>)}</div> : <div className="mt-8 rounded-2xl border border-dashed border-border p-12 text-center"><Images className="mx-auto text-muted" size={30}/><h2 className="mt-4 font-semibold">Your first collection starts here</h2><p className="mt-2 text-sm text-muted">Save the images you love into albums.</p></div>}</main></>;
}
