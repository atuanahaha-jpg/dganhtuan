import type { MetadataRoute } from "next";
export default function sitemap(): MetadataRoute.Sitemap {
  const base = process.env.APP_URL || "http://localhost:3000";
  return ["", "/trending", "/explore", "/about", "/terms", "/privacy"].map((path) => ({ url: `${base}${path}`, lastModified: new Date(), changeFrequency: "daily", priority: path === "" ? 1 : 0.6 }));
}
