import Link from "next/link";
import { Navbar } from "@/components/navbar";
export const metadata = { title: "Reset password" };
export default function ForgotPasswordPage() { return <><Navbar/><main className="container max-w-lg py-16"><h1 className="font-display text-3xl font-bold">Reset your password</h1><p className="mt-3 text-sm leading-6 text-muted">Password reset emails need a configured email provider and one-time token workflow. No email is sent by this starter page yet.</p><Link href="/login" className="mt-6 inline-block rounded-xl bg-primary px-5 py-3 text-sm font-semibold text-white">Back to sign in</Link></main></>; }
