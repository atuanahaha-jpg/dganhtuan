import { Navbar } from "@/components/navbar";
import { Feed } from "@/components/feed";
import { Flame } from "lucide-react";

export const metadata = { title: "Trending" };
export default function TrendingPage() {
  return <><Navbar/><main className="container py-10"><div className="mb-8 flex items-center gap-4"><div className="grid size-14 place-items-center rounded-2xl bg-gradient-to-br from-orange-500/20 to-pink-500/20 text-orange-300"><Flame size={27}/></div><div><p className="text-xs font-semibold uppercase tracking-[.2em] text-primary">Community pulse</p><h1 className="font-display text-3xl font-bold">Trending now</h1><p className="mt-1 text-sm text-muted">Discover what the community is loving.</p></div></div><div className="mb-6 flex flex-wrap gap-2">{["Today","This week","This month","All time"].map((x,i)=><span key={x} className={`rounded-full border px-4 py-2 text-sm ${i===0?"border-primary bg-primary text-white":"border-border bg-surface text-muted"}`}>{x}</span>)}</div><Feed/></main></>;
}
