"use client";
import Link from "next/link";
import { useState } from "react";
import { signIn } from "next-auth/react";
import { toast } from "sonner";
import { Image as ImageIcon } from "lucide-react";

export default function RegisterPage() {
  const [busy, setBusy] = useState(false);
  async function submit(formData: FormData) {
    setBusy(true);
    const response = await fetch("/api/register", { method: "POST", headers: {"Content-Type":"application/json"}, body: JSON.stringify(Object.fromEntries(formData.entries())) });
    const body = await response.json() as { error?: { message?: string } };
    setBusy(false);
    if (!response.ok) { toast.error(body.error?.message || "Could not create account."); return; }
    const result = await signIn("credentials", { email: String(formData.get("email")), password: String(formData.get("password")), redirect: false });
    if (result?.error) toast.success("Account created. Please sign in.");
    window.location.href = "/";
  }
  return <main className="flex min-h-screen items-center justify-center px-5 py-12"><div className="w-full max-w-md"><Link href="/" className="mb-8 flex items-center gap-2 font-display text-xl font-bold"><ImageIcon className="text-primary"/>Photoshop</Link><p className="text-xs font-semibold tracking-[.2em] text-primary">YOUR WORLD, YOUR WAY</p><h1 className="mt-2 font-display text-3xl font-bold">Create your account</h1><p className="mt-2 text-sm text-muted">Join a community built around creativity.</p><form action={submit} className="mt-7 space-y-4"><label className="block text-sm">Display name<input name="name" required minLength={2} maxLength={80} className="mt-2 w-full rounded-xl border border-border bg-surface px-4 py-3 outline-none focus:border-primary"/></label><label className="block text-sm">Username<input name="username" required minLength={3} maxLength={24} pattern="[A-Za-z0-9_]+" className="mt-2 w-full rounded-xl border border-border bg-surface px-4 py-3 outline-none focus:border-primary" placeholder="creative_handle"/></label><label className="block text-sm">Email<input name="email" type="email" required className="mt-2 w-full rounded-xl border border-border bg-surface px-4 py-3 outline-none focus:border-primary"/></label><label className="block text-sm">Password<input name="password" type="password" required minLength={10} autoComplete="new-password" className="mt-2 w-full rounded-xl border border-border bg-surface px-4 py-3 outline-none focus:border-primary" placeholder="At least 10 characters"/></label><button disabled={busy} className="w-full rounded-xl bg-primary py-3 font-semibold text-white disabled:opacity-50">{busy?"Creating account…":"Create account"}</button></form><p className="mt-6 text-center text-sm text-muted">Already have an account? <Link href="/login" className="font-semibold text-primary">Sign in</Link></p></div></main>;
}
