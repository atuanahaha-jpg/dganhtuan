import Link from "next/link";
import { Navbar } from "@/components/navbar";
import { auth } from "@/lib/auth";
import { redirect } from "next/navigation";
import { Settings, UserRound, ShieldCheck, Bell } from "lucide-react";

export const metadata = { title: "Settings" };
export default async function SettingsPage() {
  const session = await auth();
  if (!session) redirect("/login");
  return <><Navbar/><main className="container max-w-4xl py-10"><p className="text-xs font-semibold uppercase tracking-[.2em] text-primary">Make it yours</p><h1 className="mt-2 font-display text-3xl font-bold">Settings</h1><p className="mt-2 text-muted">Manage your account and privacy preferences.</p><div className="mt-8 grid gap-3">{[[UserRound,"Profile","Your name, username, and bio","/u"],[ShieldCheck,"Security","Password and connected accounts","/settings/security"],[Bell,"Notifications","Control what you hear about","/settings/notifications"],[Settings,"Privacy","Visibility and account preferences","/settings/privacy"]].map(([Icon,title,desc,href])=><Link key={String(title)} href={String(href)} className="glass flex items-center gap-4 rounded-2xl p-5 transition hover:border-primary/40"><span className="grid size-11 place-items-center rounded-xl bg-primary/10 text-primary"><Icon size={20}/></span><span className="flex-1"><span className="block font-semibold">{String(title)}</span><span className="mt-1 block text-sm text-muted">{String(desc)}</span></span><span className="text-muted">→</span></Link>)}</div><p className="mt-6 text-xs text-muted">Account deletion, email verification, password reset, and preference updates require the corresponding verified server workflows to be configured before production launch.</p></main></>;
}
