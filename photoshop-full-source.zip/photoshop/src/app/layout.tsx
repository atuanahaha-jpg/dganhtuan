import type { Metadata, Viewport } from "next";
import { Inter, Space_Grotesk } from "next/font/google";
import "./globals.css";
import { Providers } from "@/components/providers";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter", display: "swap" });
const space = Space_Grotesk({ subsets: ["latin"], variable: "--font-space", display: "swap" });

export const metadata: Metadata = {
  title: { default: "Photoshop — Share your world", template: "%s · Photoshop" },
  description: "Discover beautiful moments, share your stories, and find your creative community.",
  metadataBase: new URL(process.env.APP_URL || "http://localhost:3000"),
  openGraph: { type: "website", siteName: "Photoshop", title: "Photoshop — Share your world", description: "A community for beautiful images and stories." },
  twitter: { card: "summary_large_image", title: "Photoshop — Share your world" }
};
export const viewport: Viewport = { themeColor: "#0B0B0D", colorScheme: "dark light" };

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en" suppressHydrationWarning className={`${inter.variable} ${space.variable}`}>
    <body><Providers>{children}</Providers></body>
  </html>;
}
