import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Heart, MessageCircle, Share2, Flag } from "lucide-react";
import { Navbar } from "@/components/navbar";
import { db } from "@/lib/db";
import { auth } from "@/lib/auth";

export async function generateMetadata({ params }: { params: Promise<{ postId: string }> }) {
  const { postId } = await params;
  const post = await db.post.findFirst({ where: { OR: [{ slug: postId }, { id: postId }], published: true, visibility: { in: ["PUBLIC", "UNLISTED"] } }, include: { images: { take: 1 } } });
  if (!post) return { title: "Post not found" };
  return { title: post.title, description: post.description || `A post shared on Photoshop: ${post.title}`, openGraph: { images: post.images[0]?.url ? [post.images[0].url] : [] } };
}

export default async function PostPage({ params }: { params: Promise<{ postId: string }> }) {
  const { postId } = await params;
  const [session, post] = await Promise.all([
    auth(),
    db.post.findFirst({
      where: { OR: [{ slug: postId }, { id: postId }], published: true, visibility: { in: ["PUBLIC", "UNLISTED"] } },
      include: {
        user: { select: { username: true, name: true, image: true } },
        images: { orderBy: { position: "asc" } },
        tags: { include: { tag: true } },
        _count: { select: { likes: true, comments: true } },
        comments: { where: { parentId: null }, orderBy: { createdAt: "desc" }, take: 30, include: { user: { select: { username: true, name: true, image: true } }, replies: { take: 10, include: { user: { select: { username: true, name: true } } } } } }
      }
    })
  ]);
  if (!post) notFound();
  const liked = session?.user?.id ? await db.like.findUnique({ where: { userId_postId: { userId: session.user.id, postId: post.id } } }) : null;
  return <><Navbar/><main className="container py-8"><div className="mx-auto grid max-w-6xl gap-8 lg:grid-cols-[minmax(0,1.4fr)_minmax(320px,.8fr)]"><div className="overflow-hidden rounded-2xl border border-border bg-surface">{post.images.map((image) => <div key={image.id} className="relative flex min-h-64 items-center justify-center bg-black/20"><Image src={image.url} alt={image.altText} width={image.width || 1400} height={image.height || 1200} unoptimized className="max-h-[80vh] w-auto max-w-full object-contain"/></div>)}</div><aside className="min-w-0"><div className="glass rounded-2xl p-5"><div className="flex items-center gap-3"><div className="grid size-11 place-items-center rounded-full bg-gradient-to-br from-blue-500 to-violet-500 font-bold">{(post.user.name || post.user.username).slice(0,1).toUpperCase()}</div><div className="min-w-0 flex-1"><p className="font-semibold">{post.user.name || post.user.username}</p><Link href={`/u/${post.user.username}`} className="text-sm text-muted">@{post.user.username}</Link></div><Link href={`/u/${post.user.username}`} className="rounded-full border border-border px-3 py-2 text-xs">View profile</Link></div><h1 className="mt-6 font-display text-2xl font-bold">{post.title}</h1>{post.description && <p className="mt-3 whitespace-pre-wrap text-sm leading-6 text-muted">{post.description}</p>}<div className="mt-4 flex flex-wrap gap-2">{post.tags.map(({tag})=><Link key={tag.id} href={`/search?q=${encodeURIComponent(tag.name)}`} className="rounded-full bg-elevated px-3 py-1.5 text-xs text-primary">#{tag.name}</Link>)}</div><div className="mt-6 flex items-center gap-3 border-y border-border py-4"><form action={`/api/posts/${post.id}/like`} method="post"><button aria-label="Like count" className={`inline-flex items-center gap-2 rounded-xl border border-border px-3 py-2 text-sm ${liked ? "text-pink-400" : "text-muted"}`}><Heart size={17} fill={liked ? "currentColor" : "none"}/>{post._count.likes}</button></form><a href="#comments" className="inline-flex items-center gap-2 rounded-xl border border-border px-3 py-2 text-sm text-muted"><MessageCircle size={17}/>{post._count.comments}</a><button onClick={undefined} className="inline-flex items-center gap-2 rounded-xl border border-border px-3 py-2 text-sm text-muted"><Share2 size={17}/>Share</button><Link href="/login" className="ml-auto rounded-xl p-2 text-muted" aria-label="Report post"><Flag size={17}/></Link></div><section id="comments" className="pt-5"><h2 className="font-semibold">Comments <span className="text-muted">({post._count.comments})</span></h2>{session?.user ? <CommentForm postId={post.id}/> : <p className="mt-3 rounded-xl bg-elevated p-3 text-sm text-muted"><Link className="text-primary" href="/login">Sign in</Link> to join the conversation.</p>}<div className="mt-5 space-y-5">{post.comments.map((comment)=><div key={comment.id}><p className="text-sm font-medium">{comment.user.name || comment.user.username} <span className="ml-1 font-normal text-muted">@{comment.user.username}</span></p><p className="mt-1 whitespace-pre-wrap text-sm text-muted">{comment.body}</p>{comment.replies.map((reply)=><div key={reply.id} className="ml-4 mt-3 border-l border-border pl-3"><p className="text-xs font-semibold">{reply.user.name || reply.user.username}</p><p className="mt-1 text-sm text-muted">{reply.body}</p></div>)}</div>)}</div></section></div></aside></div></main></>;
}

function CommentForm({ postId }: { postId: string }) {
  return <form action={`/api/posts/${postId}/comments`} method="post" className="mt-3 flex gap-2"><input name="body" required maxLength={2000} placeholder="Share a thoughtful comment..." className="min-w-0 flex-1 rounded-xl border border-border bg-elevated px-3 py-2 text-sm outline-none focus:border-primary"/><button className="rounded-xl bg-primary px-4 text-sm font-semibold text-white">Send</button></form>;
}
