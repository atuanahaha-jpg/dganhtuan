"use client";
import Link from "next/link";
import { useState } from "react";
import { signIn } from "next-auth/react";
import { Image as ImageIcon, Eye, EyeOff } from "lucide-react";
import { toast } from "sonner";

export default function LoginPage() {
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  async function submit(formData: FormData) {
    setBusy(true);
    const result = await signIn("credentials", { email: String(formData.get("email")), password: String(formData.get("password")), redirect: false });
    setBusy(false);
    if (result?.error) toast.error("Email or password is incorrect.");
    else window.location.href = "/";
  }
  return <main className="grid min-h-screen lg:grid-cols-2"><section className="hidden flex-col justify-between bg-hero-mesh p-12 lg:flex"><Link href="/" className="flex items-center gap-2 font-display text-xl font-bold"><span className="grid size-9 place-items-center rounded-xl bg-gradient-to-br from-blue-500 to-violet-500"><ImageIcon size={19}/></span>Photoshop</Link><div><h1 className="font-display text-5xl font-bold leading-tight">Your next favorite<br/><span className="text-blue-400">moment awaits.</span></h1><p className="mt-5 max-w-md text-muted">Find inspiration, meet creators, and share what makes your world unique.</p></div><p className="text-xs text-muted">More than just images. It’s a community.</p></section><section className="flex items-center justify-center px-6 py-12"><div className="w-full max-w-md"><Link href="/" className="mb-10 flex items-center gap-2 font-display text-xl font-bold lg:hidden"><ImageIcon className="text-primary"/>Photoshop</Link><p className="text-sm font-semibold text-primary">WELCOME BACK</p><h2 className="mt-2 font-display text-3xl font-bold">Sign in to Photoshop</h2><p className="mt-2 text-sm text-muted">Your creative community is waiting.</p><form action={submit} className="mt-8 space-y-4"><label className="block text-sm">Email address<input name="email" type="email" required autoComplete="email" className="mt-2 w-full rounded-xl border border-border bg-surface px-4 py-3 outline-none focus:border-primary" placeholder="you@example.com"/></label><label className="block text-sm">Password<span className="mt-2 flex rounded-xl border border-border bg-surface focus-within:border-primary"><input name="password" type={show?"text":"password"} required autoComplete="current-password" className="min-w-0 flex-1 bg-transparent px-4 py-3 outline-none" placeholder="Your password"/><button type="button" onClick={()=>setShow(!show)} className="px-3 text-muted" aria-label={show?"Hide password":"Show password"}>{show?<EyeOff size={18}/>:<Eye size={18}/>}</button></span></label><div className="flex justify-end"><Link href="/forgot-password" className="text-sm text-primary">Forgot password?</Link></div><button disabled={busy} className="w-full rounded-xl bg-primary py-3 font-semibold text-white disabled:opacity-50">{busy?"Signing in…":"Sign in"}</button></form><div className="my-5 flex items-center gap-3 text-xs text-muted"><span className="h-px flex-1 bg-border"/><span>OR</span><span className="h-px flex-1 bg-border"/></div><button onClick={()=>void signIn("google",{callbackUrl:"/"})} className="w-full rounded-xl border border-border py-3 text-sm font-medium hover:bg-elevated">Continue with Google</button><p className="mt-6 text-center text-sm text-muted">New to Photoshop? <Link href="/register" className="font-semibold text-primary">Create an account</Link></p><p className="mt-8 text-center text-xs text-muted">By continuing, you agree to our <Link href="/terms" className="underline">Terms</Link> and <Link href="/privacy" className="underline">Privacy Policy</Link>.</p></div></section></main>;
}
