import { NextResponse } from "next/server";
import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import { randomUUID } from "node:crypto";
import { z } from "zod";
import { auth } from "@/lib/auth";

const schema = z.object({
  filename: z.string().min(1).max(180),
  contentType: z.enum(["image/jpeg", "image/png", "image/webp", "image/avif"]),
  size: z.number().int().positive().max(15 * 1024 * 1024)
});

export async function POST(request: Request) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: { code: "UNAUTHORIZED", message: "Sign in to upload." } }, { status: 401 });
  const parsed = schema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: { code: "INVALID_FILE", message: "Use a supported image up to 15 MB." } }, { status: 400 });

  const { R2_ACCOUNT_ID, R2_ACCESS_KEY_ID, R2_SECRET_ACCESS_KEY, R2_BUCKET_NAME, R2_PUBLIC_URL } = process.env;
  if (!R2_ACCOUNT_ID || !R2_ACCESS_KEY_ID || !R2_SECRET_ACCESS_KEY || !R2_BUCKET_NAME || !R2_PUBLIC_URL) {
    return NextResponse.json({ error: { code: "STORAGE_NOT_CONFIGURED", message: "Image storage is not configured yet." } }, { status: 503 });
  }
  const client = new S3Client({
    region: "auto",
    endpoint: `https://${R2_ACCOUNT_ID}.r2.cloudflarestorage.com`,
    credentials: { accessKeyId: R2_ACCESS_KEY_ID, secretAccessKey: R2_SECRET_ACCESS_KEY }
  });
  const ext = parsed.data.contentType.split("/")[1].replace("jpeg", "jpg");
  const key = `users/${session.user.id}/${randomUUID()}.${ext}`;
  const command = new PutObjectCommand({
    Bucket: R2_BUCKET_NAME, Key: key, ContentType: parsed.data.contentType,
    Metadata: { owner: session.user.id }
  });
  const uploadUrl = await getSignedUrl(client, command, { expiresIn: 300 });
  return NextResponse.json({ data: { uploadUrl, publicUrl: `${R2_PUBLIC_URL.replace(/\/$/, "")}/${key}`, key, expiresIn: 300 } });
}
