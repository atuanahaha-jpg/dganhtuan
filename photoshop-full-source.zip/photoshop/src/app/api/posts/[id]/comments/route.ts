import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { db } from "@/lib/db";
import { commentSchema } from "@/lib/validation";

export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const comments = await db.comment.findMany({
    where: { postId: id, parentId: null },
    orderBy: { createdAt: "asc" },
    take: 100,
    include: {
      user: { select: { username: true, name: true, image: true } },
      replies: { take: 20, orderBy: { createdAt: "asc" }, include: { user: { select: { username: true, name: true, image: true } } } }
    }
  });
  return NextResponse.json({ data: comments });
}

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: { code: "UNAUTHORIZED", message: "Sign in to comment." } }, { status: 401 });
  const { id } = await context.params;
  const parsed = commentSchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: { code: "VALIDATION_ERROR", message: "Invalid comment." } }, { status: 400 });
  const post = await db.post.findFirst({ where: { id, published: true, visibility: { in: ["PUBLIC", "UNLISTED"] } }, select: { id: true } });
  if (!post) return NextResponse.json({ error: { code: "NOT_FOUND", message: "Post not found." } }, { status: 404 });
  if (parsed.data.parentId) {
    const parent = await db.comment.findFirst({ where: { id: parsed.data.parentId, postId: id }, select: { id: true } });
    if (!parent) return NextResponse.json({ error: { code: "INVALID_PARENT", message: "Reply target not found." } }, { status: 400 });
  }
  const comment = await db.comment.create({ data: { body: parsed.data.body, parentId: parsed.data.parentId, postId: id, userId: session.user.id }, include: { user: { select: { username: true, name: true, image: true } } } });
  return NextResponse.json({ data: comment }, { status: 201 });
}
