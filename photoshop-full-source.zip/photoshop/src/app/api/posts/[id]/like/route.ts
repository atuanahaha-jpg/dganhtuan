import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { db } from "@/lib/db";

export async function POST(_request: Request, context: { params: Promise<{ id: string }> }) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: { code: "UNAUTHORIZED", message: "Sign in to like posts." } }, { status: 401 });
  const { id } = await context.params;
  const post = await db.post.findFirst({ where: { id, published: true, visibility: { in: ["PUBLIC", "UNLISTED"] } }, select: { id: true } });
  if (!post) return NextResponse.json({ error: { code: "NOT_FOUND", message: "Post not found." } }, { status: 404 });
  const existing = await db.like.findUnique({ where: { userId_postId: { userId: session.user.id, postId: id } } });
  if (existing) {
    await db.like.delete({ where: { userId_postId: { userId: session.user.id, postId: id } } });
    return NextResponse.json({ data: { liked: false } });
  }
  await db.like.create({ data: { userId: session.user.id, postId: id } });
  return NextResponse.json({ data: { liked: true } });
}
