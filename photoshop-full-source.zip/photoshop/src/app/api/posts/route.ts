import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { db } from "@/lib/db";
import { createPostSchema } from "@/lib/validation";
import { slugify } from "@/lib/utils";
import { randomUUID } from "node:crypto";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const cursor = url.searchParams.get("cursor");
  const limit = Math.min(Math.max(Number(url.searchParams.get("limit") ?? 18), 1), 40);
  const posts = await db.post.findMany({
    where: { published: true, visibility: "PUBLIC" },
    take: limit + 1,
    ...(cursor ? { skip: 1, cursor: { id: cursor } } : {}),
    orderBy: [{ createdAt: "desc" }, { id: "desc" }],
    include: {
      user: { select: { id: true, username: true, name: true, image: true } },
      images: { orderBy: { position: "asc" }, take: 1 },
      tags: { include: { tag: true } },
      _count: { select: { likes: true, comments: true } }
    }
  });
  const hasMore = posts.length > limit;
  const items = hasMore ? posts.slice(0, limit) : posts;
  return NextResponse.json({
    data: items,
    nextCursor: hasMore ? items[items.length - 1]?.id ?? null : null
  }, { headers: { "Cache-Control": "public, s-maxage=30, stale-while-revalidate=120" } });
}

export async function POST(request: Request) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: { code: "UNAUTHORIZED", message: "Sign in to publish." } }, { status: 401 });
  const parsed = createPostSchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: { code: "VALIDATION_ERROR", message: "Please check your post details.", issues: parsed.error.flatten() } }, { status: 400 });

  const data = parsed.data;
  const base = slugify(data.title) || "post";
  const slug = `${base}-${randomUUID().slice(0, 8)}`;
  const post = await db.post.create({
    data: {
      slug, title: data.title, description: data.description,
      visibility: data.visibility, userId: session.user.id,
      images: { create: [{ url: data.imageUrl, thumbnailUrl: data.imageUrl, altText: data.altText, mimeType: "image/unknown", sizeBytes: 0 }] },
      tags: { create: await Promise.all([...new Set(data.tags.map((tag) => tag.toLowerCase().replace(/^#/, "")))].map((name) => ({
        tag: { connectOrCreate: { where: { name }, create: { name } } }
      }))) }
    },
    include: { images: true, tags: { include: { tag: true } } }
  });
  return NextResponse.json({ data: post }, { status: 201 });
}
