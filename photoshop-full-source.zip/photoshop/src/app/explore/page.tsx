import Link from "next/link";
import { Navbar } from "@/components/navbar";
const topics = [
  ["Nature", "Landscapes, wildlife, and the natural world", "🌿"],
  ["Photography", "Techniques, ideas, and visual stories", "📷"],
  ["Travel", "Places that make you see things differently", "🧭"],
  ["Architecture", "Shapes, spaces, and built environments", "🏙️"],
  ["Animals", "Tiny companions and wild encounters", "🐈"],
  ["Art & Design", "Creative experiments and visual culture", "🎨"],
  ["Food", "Recipes, textures, and delicious details", "🍜"],
  ["Technology", "The tools shaping tomorrow", "✨"]
];
export default function ExplorePage() {
  return <><Navbar/><main className="container py-10"><p className="text-xs font-semibold uppercase tracking-[.2em] text-primary">Curiosity starts here</p><h1 className="mt-2 font-display text-4xl font-bold">Explore interests</h1><p className="mt-3 max-w-xl text-muted">Follow the ideas you love and find creators who see the world like you do.</p><div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{topics.map(([title,desc,emoji])=><Link key={title} href={`/search?q=${encodeURIComponent(title.toLowerCase())}`} className="glass rounded-2xl p-5 transition hover:-translate-y-1 hover:border-primary/50"><div className="text-3xl">{emoji}</div><h2 className="mt-4 font-display text-lg font-semibold">{title}</h2><p className="mt-2 text-sm leading-6 text-muted">{desc}</p><p className="mt-5 text-sm text-primary">Explore topic →</p></Link>)}</div></main></>;
}
