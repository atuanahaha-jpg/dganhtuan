import { redirect } from "next/navigation";
import { auth } from "@/lib/auth";
import { db } from "@/lib/db";
import { Navbar } from "@/components/navbar";
import { ShieldCheck, Users, Images, Flag } from "lucide-react";

export const metadata = { title: "Admin dashboard" };
export default async function AdminPage() {
  const session = await auth();
  if (!session?.user?.id) redirect("/login");
  const user = await db.user.findUnique({ where: { id: session.user.id }, select: { role: true } });
  if (user?.role !== "ADMIN") redirect("/");
  const [users, posts, reports] = await Promise.all([db.user.count(), db.post.count(), db.report.count({ where: { status: "OPEN" } })]);
  const metrics = [[Users,"Users",users],[Images,"Posts",posts],[Flag,"Open reports",reports]];
  return <><Navbar/><main className="container py-10"><div className="flex items-center gap-3"><ShieldCheck className="text-primary" size={28}/><div><p className="text-xs font-semibold uppercase tracking-[.2em] text-primary">Moderation center</p><h1 className="font-display text-3xl font-bold">Admin dashboard</h1></div></div><div className="mt-8 grid gap-4 sm:grid-cols-3">{metrics.map(([Icon,label,value])=><div key={String(label)} className="glass rounded-2xl p-5"><Icon className="text-primary"/><p className="mt-5 text-sm text-muted">{String(label)}</p><p className="mt-1 font-display text-3xl font-bold">{String(value)}</p></div>)}</div><p className="mt-8 rounded-2xl border border-border p-5 text-sm text-muted">Access is restricted to accounts whose database role is ADMIN. Add audited moderation actions before using this dashboard to manage live content.</p></main></>;
}
