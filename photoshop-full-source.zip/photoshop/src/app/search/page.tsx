import { Navbar } from "@/components/navbar";
import { Feed } from "@/components/feed";
import { Search } from "lucide-react";

export const metadata = { title: "Search" };
export default async function SearchPage({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const { q = "" } = await searchParams;
  return <><Navbar/><main className="container py-10"><div className="mb-8"><div className="flex items-center gap-2 text-primary"><Search size={18}/><span className="text-xs font-semibold uppercase tracking-[.2em]">Discover</span></div><h1 className="mt-2 font-display text-3xl font-bold">Search Photoshop</h1><p className="mt-2 text-muted">{q ? `Showing the community feed for “${q}”.` : "Search images, creators, and tags."}</p></div><form className="mb-8 flex max-w-2xl gap-2" action="/search"><input name="q" defaultValue={q} placeholder="Try nature, travel, or a creator..." className="min-w-0 flex-1 rounded-xl border border-border bg-surface px-4 py-3 outline-none focus:border-primary"/><button className="rounded-xl bg-primary px-5 font-semibold text-white">Search</button></form><Feed/></main></>;
}
